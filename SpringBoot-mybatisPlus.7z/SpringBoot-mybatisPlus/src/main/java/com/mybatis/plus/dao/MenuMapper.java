package com.mybatis.plus.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mybatis.plus.entity.SysMenu;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MenuMapper extends BaseMapper<SysMenu> {


}
