package com.mybatis.plus.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.mybatis.plus.entity.SysMenu;

public interface MenuService extends IService<SysMenu> {

}
