package com.mybatis.plus.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.mybatis.plus.entity.Group_info;

public interface GroupService extends IService<Group_info> {

}
